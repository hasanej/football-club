/*
 * Submission 1 - Kotlin Android Developer Expert
 * Developer : Hasan El Jabir
 */

package id.hasaneljabir.footbalclub.Activity

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import com.squareup.picasso.Picasso
import id.hasaneljabir.footbalclub.R

class FootbalClubDetailActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_footbal_club_detail)
        bindViews()
    }

    private fun bindViews() {
        val img_football_club_logo = findViewById<ImageView>(R.id.img_football_club_logo)
        val txt_footbal_club_name = findViewById<TextView>(R.id.txt_footbal_club_name)
        val txt_footbal_club_description = findViewById<TextView>(R.id.txt_footbal_club_description)

        Picasso.get().load(intent.getIntExtra("logo", 0)).into(img_football_club_logo)
        txt_footbal_club_name.text = intent.getStringExtra("name")
        txt_footbal_club_description.text = intent.getStringExtra("description")
    }
}