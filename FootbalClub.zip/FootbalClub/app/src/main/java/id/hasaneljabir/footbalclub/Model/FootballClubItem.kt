/*
 * Submission 1 - Kotlin Android Developer Expert
 * Developer : Hasan El Jabir
 */

package id.hasaneljabir.footbalclub.Model

data class FootballClubItem (val logo: Int?, val name: String?, val description: String?)